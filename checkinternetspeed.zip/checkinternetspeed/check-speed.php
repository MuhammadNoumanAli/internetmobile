<?php
require 'vendor/autoload.php';

$speedtest = new NextpostTech\Speedtest\Speedtest();
print_r($speedtest);
die;
// $speedtest->getServers();
// $speedtest->getBestServer();
// $speedtest->download();
// $speedtest->upload();

// $results = $speedtest->results();

// print_r($results);

$config = new NextpostTech\Speedtest\Config();

$config->setCallback(function ($results) { print_r($results); });

$speedtest = new NextpostTech\Speedtest\Speedtest($config);
print_r($config);
$speedtest->getServers();
$speedtest->getBestServer();
$results =$speedtest->download();
print_r($results);
